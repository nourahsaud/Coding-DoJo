from main import MyClass
