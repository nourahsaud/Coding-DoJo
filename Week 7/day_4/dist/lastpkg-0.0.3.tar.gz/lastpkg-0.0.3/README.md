### MyClass Package Details
    - This package computes the mean, and do some other operations like retrieve max and min return sorted list.